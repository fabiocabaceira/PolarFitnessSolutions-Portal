package org.example;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MosquittoCallBack implements MqttCallback
{
    public void connectionLost(Throwable throwable) {
        System.out.println("Perda de ligação ao mosquitto");
    }


    public void messageArrived(String s, MqttMessage mqttMessage) throws
            Exception {
        System.out.println("Mensagem recebida:\n\t" +
                new String(mqttMessage.getPayload()) + "Planos de treino/" + s);
    }

    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
        // Não usado, para já…
    }
}

