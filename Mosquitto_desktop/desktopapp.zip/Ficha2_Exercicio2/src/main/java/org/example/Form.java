package org.example;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.StringWriter;
import java.nio.file.Paths;

public class Form extends JPanel {



    private final JButton btnconnect = new JButton(new AbstractAction("Connect") {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                MqttClient client = new MqttClient("tcp://localhost:1883",
                        MqttClient.generateClientId());
                client.connect();
              client.subscribe("Planos de treino/2");
                client.subscribe("Planos de nutricao/#");
                client.disconnect();
            } catch (Exception ex) {
              ex.printStackTrace();
            }
        }
    });

    private final JButton btnreceber= new JButton(new AbstractAction("Receber"){
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                MqttClient client = null;
                 client = new MqttClient("127.0.0.1",
                        MqttClient.generateClientId());
                 client.setCallback(new MosquittoCallBack());
                client.connect();
                client.subscribe("Planos de treino/");
                client.subscribe("Planos de nutricao/");

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    });



    public Form(){

        setPreferredSize(new Dimension(250, 300));

        add(btnconnect);
        add(btnreceber);
    }

}
