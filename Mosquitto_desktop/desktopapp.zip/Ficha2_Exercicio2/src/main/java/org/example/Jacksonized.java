package org.example;

public @interface Jacksonized {
}
