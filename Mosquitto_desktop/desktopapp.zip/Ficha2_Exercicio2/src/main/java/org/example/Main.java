package org.example;


import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Form form = new Form();
        JFrame frame = new JFrame("SwingExample"); // uses borderlayout
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.add(form, BorderLayout.CENTER); // add form to center position
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }
}